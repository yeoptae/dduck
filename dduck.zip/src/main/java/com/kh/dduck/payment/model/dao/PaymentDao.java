package com.kh.dduck.payment.model.dao;

public interface PaymentDao {

}
