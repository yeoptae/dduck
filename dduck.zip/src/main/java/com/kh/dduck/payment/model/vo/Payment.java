package com.kh.dduck.payment.model.vo;

public class Payment {

}
