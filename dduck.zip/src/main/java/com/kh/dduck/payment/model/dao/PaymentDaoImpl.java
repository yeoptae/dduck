package com.kh.dduck.payment.model.dao;

public class PaymentDaoImpl implements PaymentDao {

}
