package com.kh.dduck.payment.model.service;

public interface PaymentService {

}
