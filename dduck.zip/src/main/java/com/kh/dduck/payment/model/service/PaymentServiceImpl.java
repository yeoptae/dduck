package com.kh.dduck.payment.model.service;

public class PaymentServiceImpl implements PaymentService {

}
