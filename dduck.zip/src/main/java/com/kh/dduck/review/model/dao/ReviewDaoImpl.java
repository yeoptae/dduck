package com.kh.dduck.review.model.dao;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.sun.javafx.collections.MappingChange.Map;

@Repository
public class ReviewDaoImpl implements ReviewDao {

	@Override
	public List<Map<String, String>> selectReviewList(SqlSessionTemplate session, int cPage, int numPerPage) {
		
		RowBounds rows = new RowBounds((cPage-1)*numPerPage,numPerPage);
		return session.selectList("review.selectReviewList",null,rows);
	}

	@Override
	public int selectReviewCount(SqlSessionTemplate session) {
		
		return session.selectOne("review.selectReviewCount");
	}

	
	
}
