package com.kh.dduck.review.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kh.dduck.common.PageBarFactory;
import com.kh.dduck.review.service.ReviewService;
import com.sun.javafx.collections.MappingChange.Map;

@Controller
public class ReviewController {
	
	@Autowired
	ReviewService service;
	
//	@Controller
//	public class DetailController {
//
//		@RequestMapping("/detail/detailView")
//		public String detailView() {
//			
//			
//			return "payment/detailView";
//		}
//		
//	}

	@RequestMapping("/detail/detailView")
	public ModelAndView ReviewView(@RequestParam(value="cPage", required=false, defaultValue="0") int cPage) {
		
		ModelAndView mv = new ModelAndView();
		
		int numPerPage = 5;
		List<Map<String,String>> list = service.selectReviewList(cPage,numPerPage);
		int totalCount = service.selectReviewCount();
		mv.addObject("pageBar",PageBarFactory.getPageBar(totalCount, cPage, numPerPage, "/dduck/detail/detailView"));
		mv.addObject("count",totalCount);
		mv.addObject("list",list);
		mv.setViewName("payment/detailView");
		
		return mv;
		
	}
}
	
